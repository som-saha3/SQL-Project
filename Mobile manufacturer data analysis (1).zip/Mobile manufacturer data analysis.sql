USE [db_SQLCaseStudies]

	SELECT * FROM DIM_DATE
	SELECT * FROM DIM_CUSTOMER
	SELECT * FROM DIM_MODEL
	SELECT * FROM FACT_TRANSACTIONS
	SELECT * FROM DIM_LOCATION
		
--Q.1 List all the states in which we have customers who have bought cellphones from 2005 till today
	
	SELECT State,SUM(QUANTITY) AS NUM_TOT_QUANTITY,SUM(TotalPrice) AS TOTAL_AMOUNT
	FROM DIM_CUSTOMER AS DC
	LEFT JOIN FACT_TRANSACTIONS AS FT ON DC.IDCUSTOMER = FT.IDCUSTOMER
	LEFT JOIN DIM_LOCATION AS DL ON DL.IDLOCATION = FT.IDLOCATION
	WHERE DATEPART(YEAR, DATE) BETWEEN 2005 AND (SELECT DATEPART(YEAR,GETDATE()))
	GROUP BY State
	
--2. What state in the US is buying more 'Samsung' cell phones?

	SELECT State,Manufacturer_Name, COUNT(Quantity)  AS NUM_TOT_QUANTIY 
	FROM FACT_TRANSACTIONS AS FT
	LEFT JOIN DIM_LOCATION AS DL ON FT.IDLocation = DL.IDLocation
	LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel
	LEFT JOIN DIM_MANUFACTURER AS DMA ON DM.IDManufacturer = DMA.IDManufacturer	
	WHERE Country = 'US' AND Manufacturer_Name = 'Samsung'
	Group By State,Manufacturer_Name
	ORDER BY NUM_TOT_QUANTIY DESC		

--3. Show the number of transactions for each model per zip code per state.
	
	SELECT DM.IDModel, State, ZipCode, SUM (TotalPrice) AS NUM_OF_TRNS 
	FROM FACT_TRANSACTIONS AS FT
	LEFT JOIN DIM_LOCATION AS DL ON FT.IDLocation = DL.IDLocation
	LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel
	GROUP BY DM.IDModel, State, ZipCode
	
--4. Show the cheapest cellphone. 
	SELECT TOP 1 IDModel,TotalPrice
	FROM FACT_TRANSACTIONS
	ORDER BY TotalPrice 
	
--5 Find out the average price for each model in the top manufacturers interms of sales quantity 
--and order by average price.

	SELECT Manufacturer_Name, Model_Name, Quantity, AVG(FT.TotalPrice) AS AVG_PRICE_EM 
	FROM
	FACT_TRANSACTIONS AS FT
	LEFT JOIN DIM_MODEL AS DM ON DM.IDModel = DM.IDModel
	LEFT JOIN DIM_MANUFACTURER AS DMA ON DM.IDManufacturer = DMA.IDManufacturer
	GROUP BY Manufacturer_Name, Model_Name, Quantity
	ORDER BY AVG_PRICE_EM DESC

--6. List the names of the customers and the average amount spent in 2009,where the average is higher than 500

	SELECT Customer_Name, AVG(FT.TotalPrice) AS AVG_SPENT_2009
	FROM DIM_CUSTOMER AS DC
	LEFT JOIN FACT_TRANSACTIONS AS FT ON DC.IDCustomer = FT.IDCustomer
	WHERE
	DATEPART(YEAR,DATE) = 2009
	GROUP BY Customer_Name
	HAVING AVG(FT.TotalPrice) > 500
--7. List if there is any model that was in the top 5 in terms of quantity,simultaneously in 2008, 2009 and 2010

	SELECT * FROM 
	( 
	 SELECT TOP 5 Model_Name
	 FROM FACT_TRANSACTIONS AS FT 
	 LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel 
	 WHERE DATEPART(YEAR,DATE) = 2008
	 GROUP BY Model_Name
	 ORDER BY SUM(Quantity) DESC 
	 ) 
	 AS TABLE1

	 INTERSECT
	 SELECT * FROM 
	( 
	 SELECT TOP 5 Model_Name
	 FROM FACT_TRANSACTIONS AS FT 
	 LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel 
	 WHERE DATEPART(YEAR,DATE) = 2009
	 GROUP BY Model_Name
	 ORDER BY SUM(Quantity) DESC 
	 ) 
	 AS TABLE2

	INTERSECT
	SELECT * FROM 
	( 
	 SELECT TOP 5 Model_Name
	 FROM FACT_TRANSACTIONS AS FT 
	 LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel 
	 WHERE DATEPART(YEAR,DATE) = 2010
	 GROUP BY Model_Name
	 ORDER BY SUM(Quantity) DESC 
	 ) 
	 AS TABLE3
--8. Show the manufacturer with the 2nd top sales in the year of 2009 and 
--the manufacturer with the 2nd top sales in the year of 2010.
	SELECT * FROM
	(
	SELECT ROW_NUMBER() OVER (PARTITION BY DATEPART( YEAR, DATE) ORDER BY SUM(Quantity) DESC) AS RNUM, 
	Manufacturer_Name, SUM (Quantity) AS TOTAL_QUANTITY, DATEPART(YEAR,DATE) AS YEAR_OF_SALES
	FROM FACT_TRANSACTIONS AS FT
	LEFT JOIN DIM_MODEL AS DM ON FT.IDModel = DM.IDModel
	LEFT JOIN DIM_MANUFACTURER AS DMA ON DM.IDManufacturer = DMA.IDManufacturer
	WHERE DATEPART(YEAR,DATE) IN (2009,2010)
	GROUP BY Manufacturer_Name,DATEPART(YEAR,DATE)) AS TBL1
	WHERE RNUM = 2
	

--9. Show the manufacturers that sold cellphone in 2010 but didn't in 2009.

	SELECT Manufacturer_Name FROM 
	(
	SELECT Manufacturer_Name, SUM(Quantity) AS TOT_QUANTITY, DATEPART(YEAR,DATE) AS SALES_IN_YEARS
	FROM FACT_TRANSACTIONS AS FT
	INNER JOIN DIM_MODEL AS DM ON FT.idModel = DM.IDModel
	INNER JOIN DIM_MANUFACTURER AS DMA ON DM.IDManufacturer = DMA.Manufacturer_Name
	WHERE DATEPART(YEAR,DATE) = 2010
	GROUP BY Manufacturer_Name, DATEPART(YEAR,DATE)) AS TBL1
	EXCEPT
	SELECT Manufacturer_Name FROM 
	(
	SELECT Manufacturer_Name, SUM(Quantity) AS TOT_QUANTITY, DATEPART(YEAR,DATE)
	FROM FACT_TRANSACTIONS AS FT
	INNER JOIN DIM_MODEL AS DM ON FT.idModel = DM.IDModel
	INNER JOIN DIM_MANUFACTURER AS DMA ON DM.IDManufacturer = DMA.Manufacturer_Name
	WHERE DATEPART(YEAR,DATE) = 2009
	GROUP BY Manufacturer_Name, DATEPART(YEAR,DATE)) AS TABLE2
	
--10. Find top 100 customers and their average spend, average quantity by eachyear. Also find the percentage of 
--change in their spend.
	
	SELECT TOP 100 Customer_Name, DC.IDCustomer,
	AVG(TotalPrice) AS TOT_AVG_PRICE,
	AVG(Quantity) AS AGV_QTY,
	DATEPART(YEAR, Date) AS YEAR
	FROM
	DIM_CUSTOMER AS DC
	LEFT JOIN FACT_TRANSACTIONS AS FT ON DC.IDCustomer = FT.IDCustomer
	GROUP BY Customer_Name, DC.IDCustomer, DATEPART(YEAR, Date)
	ORDER BY YEAR DESC, AGV_QTY DESC,TOT_AVG_PRICE DESC